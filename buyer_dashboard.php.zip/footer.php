
<footer class="text-center py-4 mt-5 bg-light text-muted border-top">
  © AutoAuction 2025
</footer>

