<div class="lot-price">
  Актуальна ціна: €<?php echo number_format($currentBid['bid_amount'] ?? 0, 0, '.', ' '); ?>
</div>

<?php if ($userId): ?>
  <?php if ($userBid && $userBid['bid_amount'] >= ($currentBid['bid_amount'] ?? 0)): ?>
    <div class="status win">Ваша ставка найвища ✅</div>
  <?php elseif ($userBid): ?>
    <div class="status lose">Вашу ставку перебито ❌</div>
  <?php endif; ?>
<?php endif; ?>
