<div class="alert alert-info">
  До завершення аукціону: <span id="countdown"></span>
</div>
<script>
  const countdown = document.getElementById("countdown");
  let timeLeft = <?php echo $endTime - $currentTime; ?>;

  function updateTimer() {
    if (timeLeft <= 0) {
      countdown.innerText = "Аукціон завершено";
      return;
    }
    const days = Math.floor(timeLeft / (60*60*24));
    const hours = Math.floor((timeLeft % (60*60*24)) / 3600);
    const minutes = Math.floor((timeLeft % 3600) / 60);
    const seconds = timeLeft % 60;
    countdown.innerText = `${days}д ${hours}г ${minutes}хв ${seconds}с`;
    timeLeft--;
    setTimeout(updateTimer, 1000);
  }
  updateTimer();
</script>
