<style>
  .car-params {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    margin-top: 30px;
  }
  .param-item {
    flex: 1 1 250px;
    background: #f2f2f7;
    border-radius: 12px;
    padding: 15px 20px;
    display: flex;
    align-items: center;
    gap: 12px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
  }
  .param-item i {
    font-size: 20px;
    color: #007aff;
    min-width: 24px;
  }
  .param-item span {
    font-weight: 600;
    color: #333;
  }
  .param-value {
    font-weight: 400;
    color: #555;
    margin-left: auto;
  }
</style>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

<div class="car-params">
  <?php
    function safe($v) { return $v ? htmlspecialchars($v) : '—'; }
  ?>
  <div class="param-item">
    <i class="fa-solid fa-calendar"></i>
    <span>Рік:</span>
    <div class="param-value"><?= safe($car['year']) ?></div>
  </div>
  <div class="param-item">
    <i class="fa-solid fa-road"></i>
    <span>Пробіг:</span>
    <div class="param-value"><?= $car['mileage_km'] ? $car['mileage_km'].' км' : '—' ?></div>
  </div>
  <div class="param-item">
    <i class="fa-solid fa-gas-pump"></i>
    <span>Паливо:</span>
    <div class="param-value"><?= safe($car['fuel_type']) ?></div>
  </div>
  <div class="param-item">
    <i class="fa-solid fa-bolt"></i>
    <span>Потужність:</span>
    <div class="param-value"><?= ($car['power_kw'] || $car['power_hp']) ? "{$car['power_kw']} kW / {$car['power_hp']} HP" : '—' ?></div>
  </div>
  <div class="param-item">
    <i class="fa-solid fa-cogs"></i>
    <span>Коробка:</span>
    <div class="param-value"><?= safe($car['gearbox']) ?></div>
  </div>
  <div class="param-item">
    <i class="fa-solid fa-car"></i>
    <span>Кузов:</span>
    <div class="param-value"><?= safe($car['body_type']) ?></div>
  </div>
  <div class="param-item">
    <i class="fa-solid fa-key"></i>
    <span>VIN:</span>
    <div class="param-value"><?= safe($car['vin']) ?></div>
  </div>
  <div class="param-item">
    <i class="fa-solid fa-id-card"></i>
    <span>Власники:</span>
    <div class="param-value"><?= $car['owners'] ?? '—' ?></div>
  </div>
</div>
