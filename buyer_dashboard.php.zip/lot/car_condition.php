<?php
require 'config.php';
session_start();

$carId = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM cars WHERE id = ?");
$stmt->execute([$carId]);
$car = $stmt->fetch();

if (!$car) {
    echo "<p>Авто не знайдено.</p>";
    exit;
}

function formatText($text) {
    return nl2br(htmlspecialchars($text ?: '—'));
}

// Витягуємо поля
$inspection_date = $car['inspection_date'] ?? '';
$damage_summary = formatText($car['damage_summary']);
$paint_report = formatText($car['paint_report']);
$service_info = formatText($car['service_info']);
$condition_description = formatText($car['condition_description']);
$paint_info = formatText($car['paint_info']);
$service_book = formatText($car['service_book'] ?? '');
$inspection_type = formatText($car['inspection_type'] ?? '');
$last_service_date = $car['last_service_date'] ?? '';
$last_service_mileage = $car['last_service_mileage'] ?? '';
$timing_belt_replacement_date = $car['timing_belt_replacement_date'] ?? '';
$timing_belt_replacement_mileage = $car['timing_belt_replacement_mileage'] ?? '';

$damage_gallery = json_decode($car['damage_gallery'] ?? '[]', true) ?: [];
$service_gallery = json_decode($car['service_gallery'] ?? '[]', true) ?: [];
?>
<!DOCTYPE html>
<html lang="uk">
<head>
  <meta charset="UTF-8">
  <title>Стан авто</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .section-block { margin-bottom: 30px; }
    .section-title { font-size: 1.25rem; font-weight: 600; margin-bottom: 10px; border-bottom: 2px solid #ccc; padding-bottom: 4px; }
    .section-content { background: #f8f9fa; padding: 15px; border-radius: 5px; }
    .gallery-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; }
    .gallery-item img { width: 100%; height: 180px; object-fit: cover; border-radius: 6px; cursor: pointer; }
    .gallery-desc { margin-top: 8px; font-size: 14px; color: #555; }
  </style>
  <script>
    function enlarge(imgSrc) {
      const overlay = document.createElement('div');
      overlay.style = 'position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.8);display:flex;align-items:center;justify-content:center;z-index:1000;';
      const img = document.createElement('img');
      img.src = imgSrc;
      img.style = 'max-width:90%;max-height:90%;border:5px solid white;border-radius:10px;';
      overlay.onclick = () => overlay.remove();
      overlay.appendChild(img);
      document.body.appendChild(overlay);
    }
  </script>
</head>
<body>
<div class="container py-4">
  <h1 class="mb-4">🔧 Стан авто: <?php echo htmlspecialchars($car['name']); ?></h1>

  <div class="section-block">
    <div class="section-title">📌 Загальні дані</div>
    <table class="table table-bordered table-sm w-100">
      <tr><th>VIN</th><td><?php echo htmlspecialchars($car['vin']); ?></td></tr>
      <tr><th>Рік</th><td><?php echo htmlspecialchars($car['year']); ?></td></tr>
      <tr><th>Двигун</th><td><?php echo htmlspecialchars($car['engine_cc']); ?> см³</td></tr>
      <tr><th>КПП</th><td><?php echo htmlspecialchars($car['gearbox']); ?></td></tr>
      <tr><th>Пробіг</th><td><?php echo htmlspecialchars($car['mileage_km']); ?> км</td></tr>
      <tr><th>Дата огляду</th><td><?php echo htmlspecialchars($inspection_date); ?></td></tr>
    </table>
  </div>

  <div class="section-block">
    <div class="section-title">⚠️ Пошкодження</div>
    <div class="section-content"><?php echo $damage_summary; ?></div>
  </div>

  <div class="section-block">
    <div class="section-title">🖼️ Фото пошкоджень</div>
    <div class="gallery-grid">
      <?php foreach ($damage_gallery as $item): ?>
        <div class="gallery-item">
          <img src="uploads/<?php echo htmlspecialchars($item['file']); ?>" onclick="enlarge(this.src)">
          <div class="gallery-desc"><?php echo htmlspecialchars($item['note'] ?? ''); ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="section-block">
    <div class="section-title">🎨 Звіт по фарбі</div>
    <div class="section-content"><?php echo $paint_report; ?></div>
  </div>

  <div class="section-block">
    <div class="section-title">🔧 Загальний технічний стан</div>
    <div class="section-content"><?php echo $condition_description; ?></div>
  </div>

  <div class="section-block">
    <div class="section-title">🛠️ Сервісна історія</div>
    <div class="section-content"><?php echo $service_info; ?></div>
  </div>

  <div class="section-block">
    <div class="section-title">📚 Книга обслуговування</div>
    <table class="table table-bordered table-sm w-100">
      <tr><th>Тип огляду</th><td><?php echo $inspection_type; ?></td></tr>
      <tr><th>Останній сервіс</th><td><?php echo $last_service_date ? date("d.m.Y", strtotime($last_service_date)) : '—'; ?> при <?php echo $last_service_mileage ?: '—'; ?> км</td></tr>
      <tr><th>Заміна ременя ГРМ</th><td><?php echo $timing_belt_replacement_date ? date("d.m.Y", strtotime($timing_belt_replacement_date)) : '—'; ?> при <?php echo $timing_belt_replacement_mileage ?: '—'; ?> км</td></tr>
      <tr><th>Коментарі</th><td><?php echo $service_book; ?></td></tr>
    </table>
  </div>

  <div class="section-block">
    <div class="section-title">📷 Фото сервісної історії</div>
    <div class="gallery-grid">
      <?php foreach ($service_gallery as $item): ?>
        <div class="gallery-item">
          <img src="uploads/<?php echo htmlspecialchars($item['file']); ?>" onclick="enlarge(this.src)">
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <a href="lot.php?id=<?php echo $carId; ?>" class="btn btn-outline-secondary mt-4">← Назад до лота</a>
</div>
</body>
</html>
