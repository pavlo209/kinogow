<?php if ($userId): ?>
  <form method="post" class="mb-2">
    <button name="toggle_favorite"
      class="btn btn-sm <?php echo $isFavorite ? 'btn-danger' : 'btn-outline-danger'; ?> float-end">
      <?php echo $isFavorite ? '✅ В обраному ' : '❤️ Додати в обране'; ?>
    </button>
  </form>
<?php endif; ?>
