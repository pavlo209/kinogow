<script>
function switchImage(src) {
  document.getElementById('mainImage').src = src;
}

// Таймер
<?php if ($endTime > $currentTime): ?>
const countdown = document.getElementById("countdown");
let timeLeft = <?php echo $endTime - $currentTime; ?>;
function updateTimer() {
  if (timeLeft <= 0) {
    countdown.innerText = "Аукціон завершено";
    return;
  }
  const days = Math.floor(timeLeft / (60*60*24));
  const hours = Math.floor((timeLeft % (60*60*24)) / 3600);
  const minutes = Math.floor((timeLeft % 3600) / 60);
  const seconds = timeLeft % 60;
  countdown.innerText = `${days}д ${hours}г ${minutes}хв ${seconds}с`;
  timeLeft--;
  setTimeout(updateTimer, 1000);
}
updateTimer();
<?php endif; ?>

// Сповіщення перебиття
setInterval(() => {
  fetch('check_bid_status.php?car_id=<?php echo $carId; ?>')
    .then(res => res.json())
    .then(data => {
      if (data.outbid) {
        showToast("🚨 Вашу ставку перебито!");
        document.querySelector('.status').innerText = "Вашу ставку перебито ❌";
        document.querySelector('.status').classList.remove("win");
        document.querySelector('.status').classList.add("lose");
      }
    });
}, 10000);

function showToast(msg) {
  const toast = document.createElement('div');
  toast.className = 'toast-msg';
  toast.textContent = msg;
  document.getElementById('toast-container')?.appendChild(toast);
  setTimeout(() => toast.remove(), 6000);
}


 function switchImage(src) {
    document.getElementById('mainImage').src = src;
  }


</script>
