<img id="mainImage" src="../uploads/<?php echo $mainImage; ?>" class="img-fluid rounded mb-3" style="max-height: 400px; object-fit: cover;">
<div class="d-flex flex-wrap gap-2">
  <?php foreach ($gallery as $img): ?>
    <img src="../uploads/<?php echo htmlspecialchars($img); ?>" onclick="document.getElementById('mainImage').src=this.src;" style="width: 90px; height: 60px; object-fit: cover; border-radius: 6px; cursor: pointer;">
  <?php endforeach; ?>
</div>
