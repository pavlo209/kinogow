<?php if ($userId): ?>
  <form method="post" class="d-grid gap-2 mt-2">
    <button type="submit" class="btn btn-warning">Зробити ставку +100 €</button>
  </form>

  <form method="post" class="mt-3">
    <label for="max_bid" class="form-label">Максимальна ціна (€):</label>
    <input type="number" name="max_bid" class="form-control" style="max-width: 200px;" required>
    <button type="submit" class="btn btn-outline-primary mt-2">Встановити автоставку</button>
  </form>
<?php else: ?>
  <p class="mt-2"><a href="login.php">Увійдіть</a>, щоб зробити ставку.</p>
<?php endif; ?>
