
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Адмінка</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="index.php">Головна</a></li>
        <li class="nav-item"><a class="nav-link" href="lots.php">Лоти</a></li>
        <li class="nav-item"><a class="nav-link" href="add_car.php">Додати авто</a></li>
        <li class="nav-item"><a class="nav-link" href="users.php">Користувачі</a></li>
      </ul>
      <span class="navbar-text">
        <a href="../logout.php" class="text-white text-decoration-none">Вийти</a>
      </span>
    </div>
  </div>
</nav>

